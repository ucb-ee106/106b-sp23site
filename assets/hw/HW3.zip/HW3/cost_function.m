function [cost] = cost_function(P, Q, R, q, u, goal)
%cost_function Cost Function for the bicycle planning optimization
%   The cost function is
%   J = sum_i=1:N (q_i' Q q_i + u_i' R u_i) + q_N+1' P q_N+1



end

