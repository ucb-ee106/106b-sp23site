%% Test 0 vectors
% The functions should at least run for these cases
assert(isequal(hat(zeros(3, 1)), zeros(3)));
assert(isequal(hat(zeros(6, 1)), zeros(4)));

%% Test other vectors
% This should probably be comprehensive enough
assert(isequal(hat(1:3), [0 -3 2; ...
                          3 0 -1; ...
                          -2 1 0]));
assert(isequal(hat(1:6), [0 -6 5 1;
                          6 0 -4 2;
                          -5 4 0 3;
                          0 0 0 0]));
                          
