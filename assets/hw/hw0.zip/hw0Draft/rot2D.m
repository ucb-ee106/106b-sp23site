function R = rot2D(theta)
    % ROT2D compute the 2x2 rotation matrix for rotaion in a 2D plane
    % counterclockwise by an angle theta
    R = nan;
end