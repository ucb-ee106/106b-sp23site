clear

%% Set up Symbolic Variables

syms q1 q2 q3 q4 real
syms dq1 dq2 dq3 dq4 real
syms ddq1 ddq2 ddq3 ddq4 real
syms L1 L2 m1 m2 I1 I2 real
syms J1 J2 K1 K2 B1 B2 real
syms g real

q = [q1; q2; q3; q4];
dq = [dq1; dq2; dq3; dq4];
ddq = [ddq1; ddq2; ddq3; ddq4];
constants = [L1; L2; m1; m2; I1; I2; J1; J2; K1; K2; B1; B2; g];

%% Your work for (a) here
% Note: You only need to come up with expressions for the kinetic and
% potential energies of the system. The provided LagrangianDynamics.m file
% will then give you the dynamics matrices.

KE = nan;
PE = nan;

%% Solutions for Standard Dynamics
[D, C, G, ~] = LagrangianDynamics(KE, PE, q, dq, [q1; q3]);

D = simplify(D);
C = simplify(C);
G = simplify(G);

LHS = D*ddq + C*dq + G;

%% Your work for (b) here



%% Solutions for Dynamics with Dampers

LHS_Dampers = nan;

%% Create Function For Autograder

matlabFunction(LHS, 'File', 'SEA_dynamics_gen', 'Vars', {[q; dq; ddq; constants]});
matlabFunction(LHS_Dampers, 'File', 'SEA_dynamics_dampers_gen', 'Vars', {[q; dq; ddq; constants]});

