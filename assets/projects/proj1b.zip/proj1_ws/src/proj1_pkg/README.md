ROS Package for EE 106B Lab 1: Trajectory Tracking with Baxter
