function n = fib(i)
    % FIB compute the ith fibonacci number
    % i must be >= 1
    % FIB(1) = 0, FIB(2) = 1
    % FIB(i) for i >=3 must satisfy FIB(i) = FIB(i-2) + FIB(i-1)
    n = nan;
end