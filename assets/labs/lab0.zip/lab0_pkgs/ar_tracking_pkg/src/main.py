import rospy
from path_planner import PathPlanner

if __name__ == '__main__':
    # Run path planner
    planner = PathPlanner('right_arm')
