%ELBOW
clear

%% Set Up Symbolic Variables
syms theta1 theta2 theta3 theta4 theta5 theta6 real
theta = [theta1; theta2; theta3; theta4; theta5; theta6];
syms L0 L1 L2 real
L = [L0; L1; L2];

%% Your Work Here


%% Solutions

gst = nan; % Forward Kinematics Solution

J_spatial = nan; % Spatial Jacobian Solution

J_body = nan; % Body Jacobian Solution

%% Create Functions for Autograder
matlabFunction(gst, 'File', 'Elbow_FK_gen', 'Vars', {[theta; L]});
matlabFunction(J_spatial, 'File', 'Elbow_Js_gen', 'Vars', {[theta; L]});
matlabFunction(J_body, 'File', 'Elbow_Jb_gen', 'Vars', {[theta; L]});

%% Help functions
% Write any help functions you need here. We've given you one as a syntax
% example

function vec = hat(v)
    vec = [0, -v(3), v(2); v(3), 0, -v(1); -v(2), v(1), 0];
end
