clear

%% Set Up Symbolic Variables
syms theta1 theta2 theta3 theta4 real
theta = [theta1; theta2; theta3; theta4];
syms L0 L1 L2 real
L = [L0; L1; L2];

%% Your Work Here






%% Solutions

gst = nan; % Forward Kinematics Solution

J_spatial = nan; % Spatial Jacobian Solution

J_body = nan; % Body Jacobian Solution

%% Create Functions for Autograder
matlabFunction(gst, 'File', 'SCARA_FK_gen', 'Vars', {[theta; L]});
matlabFunction(J_spatial, 'File', 'SCARA_Js_gen', 'Vars', {[theta; L]});
matlabFunction(J_body, 'File', 'SCARA_Jb_gen', 'Vars', {[theta; L]});


%% Help functions
% Write any help functions you need here. We've given you one as a syntax
% example

function vec = hat(v)
    vec = [0, -v(3), v(2); v(3), 0, -v(1); -v(2), v(1), 0];
end
