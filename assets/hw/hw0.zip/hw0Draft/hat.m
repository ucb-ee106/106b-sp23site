function vHat = hat(v)
    % HAT compute the appropriate hat matrix for input vector v
    % for length 3 v, HAT(v) should return a 3x3 matrix such that
    % HAT(v) * w = cross(v, w)
    % for length 6 v, HAT(v) should return a 4x4 matrix such that
    % HAT(v) = [[HAT(v(4:6)), v(1:3)]; 
    %           [0, 0, 0, 0]]
    vHat = nan;
end