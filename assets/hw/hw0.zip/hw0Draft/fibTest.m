%% Test Base Case
% Test first two inputs
assert(fib(1) == 0, "First fibonacci number is 0");
assert(fib(2) == 1, "Second fibonacci number is 1");

%% Test General Inputs
% Just picked some random numbers here
assert(fib(5) == 3, "Error with 5th fibonacci number")
assert(fib(10) == 34, "Error with 10th fibonacci number");
assert(fib(15) == 377, "Error with 15th fibonacci number");