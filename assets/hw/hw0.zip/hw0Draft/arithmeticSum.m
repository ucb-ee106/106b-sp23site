function sum = arithmeticSum(low, high)
    sum = 0;
    for i=low:high
        sum = sum + i;
    end
end